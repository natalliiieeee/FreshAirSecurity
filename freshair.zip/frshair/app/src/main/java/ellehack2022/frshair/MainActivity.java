package ellehack2022.frshair;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class MainActivity extends AppCompatActivity {
    EditText firstName,lastName,to,from;
    Button button;
    DatabaseReference reff;
    Member member;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setTitle("Team Fresh Air");

        button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNewActivity();
            }
        });
        firstName=(EditText)findViewById(R.id.firstName);
        lastName=(EditText)findViewById(R.id.lastName);
//        to=(EditText)findViewById(R.id.to);
//        from=(EditText)findViewById(R.id.from);
        button=(Button)findViewById(R.id.button);
        member=new Member();
        reff = FirebaseDatabase.getInstance().getReference().child("Member");
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                member.setFirstName(firstName.getText().toString().trim());
                member.setLastName(lastName.getText().toString().trim());
                member.setFrom(from.getText().toString().trim());
                member.setTo(to.getText().toString().trim());
//                Toast.makeText( datainsert.this, "data insert was successful", Toast.LENGTH_LONG ).show();
            }
        });
    }


    private void openNewActivity() {
        Intent intent = new Intent(this, SecondActivity.class);
        startActivity(intent);
    }
}